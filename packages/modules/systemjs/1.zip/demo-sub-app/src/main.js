import Helloworld from './components/Helloworld.vue';

export {Helloworld};
export const a = 1;
