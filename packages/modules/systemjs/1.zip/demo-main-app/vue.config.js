module.exports = {
    lintOnSave: false,
    configureWebpack: config => {
        config.externals = ['systemjs', 'vue', '@vue/composition-api'];
        config.module.rules.unshift({
            parser: {system: false}
        });
        config.output.libraryTarget = 'umd';
    },
    devServer: {
        port: 8788
    }
};
