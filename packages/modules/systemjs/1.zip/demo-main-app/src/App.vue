<template>
  <div>
    <div>main app</div>
    <div>
      <p>hello world:</p>
      <hello-world />
      a:{{ a }}
      <button @click="handleClick">set a = 1</button>
    </div>
  </div>
</template>

<script>
import { computed, defineComponent } from "@vue/composition-api";
export default defineComponent({
  data() {
    return { a: 0 };
  },
  components: {
    HelloWorld: () => System.import("subapp1").then((r) => r.Helloworld),
  },
  computed: {},
  methods: {
    handleClick() {
      System.import("subapp1").then((r) => (this.a = r.a));
    },
  },
});
</script>

<style>
</style>